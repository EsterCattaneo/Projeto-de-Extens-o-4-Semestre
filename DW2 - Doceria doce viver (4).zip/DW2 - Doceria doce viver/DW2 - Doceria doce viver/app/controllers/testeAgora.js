module.exports.testeAgora = (app, req, res) => {
    //aqui vamos fazer a chamada para o model do banco de dados.
    console.log('[Controller TesteAgora]');
    res.render('testeAgora.ejs', { });
  };
  